#!/usr/bin/env bash
python eval.py $1 $2